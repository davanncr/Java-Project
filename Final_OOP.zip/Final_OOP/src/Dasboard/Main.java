package Dasboard;
public class Main {
    public static void main(String[] args){
        new Dasboard();
    }
}