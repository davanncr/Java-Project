package Feature;

import javax.swing.*;

public class Leaving {
    public static JPanel getPanel(){
        return new JPanel();
    }
}
