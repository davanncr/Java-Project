package Feature;

import javax.swing.*;

public class History {
    public static JPanel getPanel(){
        return new JPanel();
    }
}
